package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.DemoService;
import com.example.demo.Model.DemoModel;
//public class DemoController {
@CrossOrigin
@RestController
public class DemoController {
	@Autowired
	DemoService ds;

	@GetMapping("/getall")
	public List getall() {
		return ds.getall();
	}

	@GetMapping("/getallID/{id}")
	public List getallID(@PathVariable Integer id) {
		return ds.getallID(id);
	}

	@RequestMapping(value = "/Insert", method = RequestMethod.POST)
	public void Insert(Integer id, String title, String author, String date_published, Integer number_of_page,
			String type_of_page) {
		ds.insert(id, title, author, date_published, number_of_page, type_of_page);
		return;
	}

	@RequestMapping(value = "/Update", method = RequestMethod.POST)
	public void Update(Integer id, String title, String author, String date_published, Integer number_of_page,
			String type_of_page) {
		ds.update(id, title, author, date_published, number_of_page, type_of_page);
	}

	@RequestMapping(value = "/Delete/{id}", method = RequestMethod.GET)
	public void Delete(@PathVariable Integer id) {
		ds.delete(id);
	}

}
