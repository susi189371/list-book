package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.Model.DemoModel;

@Service

public class DemoService {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List getall() {
		String query = "SELECT *FROM desc_book";
		List data = jdbcTemplate.queryForList(query);
		return data;
	}

	public List getallID(Integer id) {
		DemoModel dm = new DemoModel();
		dm.setId(id);
		String query = "SELECT * FROM desc_book where id=" + id;
		List data = jdbcTemplate.queryForList(query);
		return data;
	}

	public String update(Integer id, String title, String author, String date_published, Integer number_of_page,
			String type_of_page) {
		DemoModel dm = new DemoModel();
		dm.setId(id);
		dm.setTitle(title);
		dm.setAuthor(author);
		dm.setDatePublished(date_published);
		dm.setNumberOfPage(number_of_page);
		dm.setTypeOfPage(type_of_page);
		String query = "UPDATE desc_book SET title =?, author=?, date_published=?, number_of_page =?, type_of_page=? where id=?";
		jdbcTemplate.update(query, dm.getTitle(), dm.getAuthor(), dm.getDatePublished(), dm.getNumberOfPage(),
				dm.getTypeOfPage(), dm.getId());
		return "Success";
	}

	public String insert(Integer id, String title, String author, String date_published, Integer number_of_page,
			String type_of_page) {
		DemoModel dm = new DemoModel(id, title, author, date_published, number_of_page, type_of_page);

		String query = "INSERT INTO `desc_book` (`id`, `title`, `author`, `date_published`, `number_of_page`, `type_of_page`) VALUES (?, ?, ?, ?, ?,?) ";
		jdbcTemplate.update(query, dm.getId(), dm.getTitle(), dm.getAuthor(), dm.getDatePublished(),
				dm.getNumberOfPage(), dm.getTypeOfPage());
		return "Success";
	}

	public String delete(Integer id) {
		DemoModel dm = new DemoModel();
		dm.setId(id);
		String query = "DELETE FROM `desc_book` WHERE id =" + id;
		jdbcTemplate.update(query);
		return "Success";
	}

}
