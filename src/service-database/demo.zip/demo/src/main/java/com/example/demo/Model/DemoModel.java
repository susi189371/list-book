package com.example.demo.Model;

public class DemoModel {

	private Integer id;
	private String title;
	private String author;
	private String date_published;
	private Integer number_of_page;
	private String type_of_page;

	public DemoModel(Integer id, String title, String author, String date_published, Integer number_of_page,
			String type_of_page) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.date_published = date_published;
		this.number_of_page = number_of_page;
		this.type_of_page = type_of_page;
	}

	public DemoModel() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDatePublished() {
		return date_published;
	}

	public void setDatePublished(String date_published) {
		this.date_published = date_published;
	}

	public Integer getNumberOfPage() {
		return number_of_page;
	}

	public void setNumberOfPage(Integer number_of_page) {
		this.number_of_page = number_of_page;
	}
	
	public String getTypeOfPage() {
		return type_of_page;
	}
	
	public void setTypeOfPage(String type_of_page) {
		this.type_of_page=type_of_page;
	}

}
